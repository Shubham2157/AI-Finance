package com.finance.tracker.statementextractor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatementExtractorApplicationTests {

	@Test
	void contextLoads() {
	}

}
